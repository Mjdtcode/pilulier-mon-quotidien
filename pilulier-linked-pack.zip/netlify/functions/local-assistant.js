
// Assistant local relié au patient actif
export async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const { text = '', context = {} } = JSON.parse(event.body || '{}');
  const t = (text || '').toLowerCase();

  if (context.patient) {
    if (/bonjour|salut/.test(t)) return ok(`Bonjour. Vous consultez le pilulier de ${context.patient}.`);
    if (/contact/.test(t)) return ok(`Onglet Contacts pour gérer le réseau de ${context.patient}.`);
    if (/rappel|notif/.test(t)) return ok('Activez les rappels et laissez le son du téléphone actif.');
  }

  const meds = Array.isArray(context.meds) ? context.meds : [];
  if (meds.length) return ok(`Médicaments notés: ${meds.slice(0, 3).map(m => m.nom).join(', ')}.`);

  return ok("Dites: « ajouter 2 doliprane lundi et vendredi jusqu’au 3 décembre ».");
}

function ok(msg) {
  return { statusCode: 200, headers: { 'content-type': 'application/json' }, body: JSON.stringify({ content: msg }) };
}
